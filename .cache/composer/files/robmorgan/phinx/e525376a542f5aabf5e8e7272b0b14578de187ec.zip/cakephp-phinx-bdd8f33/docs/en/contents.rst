Contents
########

.. toctree::
   :maxdepth: 2
   :caption: Phinx

   intro
   goals
   install
   migrations
   seeding
   commands
   configuration
   copyright
