<?php
declare(strict_types=1);

class_exists('Cake\Database\Expression\ComparisonExpression');

deprecationWarning('`Comparison` deprecated in 4.1.0, use `ComparisonExpression` instead.');
