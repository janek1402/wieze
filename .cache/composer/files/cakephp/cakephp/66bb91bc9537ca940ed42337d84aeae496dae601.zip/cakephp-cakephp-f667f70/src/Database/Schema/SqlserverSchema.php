<?php
declare(strict_types=1);

// @deprecated 4.1.0 Load new class location and alias for old location
class_exists('Cake\Database\Schema\SqlServerSchemaDialect');
