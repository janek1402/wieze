.. toctree::
    :maxdepth: 2
    :caption: CakePHP Migrations

    /index
