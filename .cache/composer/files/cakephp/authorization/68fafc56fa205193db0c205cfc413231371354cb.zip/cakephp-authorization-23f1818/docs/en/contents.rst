Contents
########

.. toctree::
    :maxdepth: 2
    :caption: CakePHP Authorization

    /index
    /policies
    /policy-resolvers
    /middleware
    /checking-authorization
    /component
    /request-authorization-middleware
    /2-0-migration-guide
