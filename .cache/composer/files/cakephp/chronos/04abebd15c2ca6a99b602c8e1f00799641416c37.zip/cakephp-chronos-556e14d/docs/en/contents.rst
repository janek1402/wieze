.. toctree::
    :maxdepth: 2
    :caption: CakePHP Chronos

    /index

    API <https://api.cakephp.org/chronos>